var typed = new Typed(".typed", {
    strings: ["I'm a full-stack web developer."],
    loop: true,
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 2000,
  });